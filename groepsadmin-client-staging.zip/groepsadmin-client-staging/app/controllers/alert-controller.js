(function() {
  'use strict';

  angular
    .module('ga.alert-controller', ['ga.services.alert'])
    .controller('AlertController', AlertController);

  AlertController.$inject = [];

  function AlertController() {

  }
})();
